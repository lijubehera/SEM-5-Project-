
Admin Login & Password (You can change this in phpmyadmin):<br/>
Login: root<br>
Password: toor<br>

