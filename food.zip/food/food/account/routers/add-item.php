<?php
include '../includes/connect.php';

$name = $_POST['name'];
$price = $_POST['price'];

// Remove 'image' column from the query.
$sql = "INSERT INTO items (name, price) VALUES ('$name', $price)";
$con->query($sql);

if(!$con) {
    echo mysqli_error($con);
}
var_dump($con->error);
// header("location: ../admin-page.php");
?>
